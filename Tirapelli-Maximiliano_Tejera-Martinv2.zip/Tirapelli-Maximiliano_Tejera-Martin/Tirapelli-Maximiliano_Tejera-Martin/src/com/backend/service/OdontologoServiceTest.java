package com.backend.service;

import com.backend.dao.impl.OdontologoDaoH2;
import com.backend.entity.Odontologo;
import org.junit.Test;

import java.sql.Connection;
import java.util.List;

import static org.junit.Assert.*;

public class OdontologoServiceTest {
    private static Connection connection = null;
    private OdontologoService odontologoService = new OdontologoService(new OdontologoDaoH2());

    @Test
    public void deberiaAgregarUnOdontologo(){
        Odontologo odoTest = new Odontologo("123456978", "PEPE", "PEPITO");

        Odontologo odontologoResult = odontologoService.guardarOdontologo(odoTest);

        assertNotNull(odontologoResult);
        assertEquals("123456978", odontologoResult.getMatricula());

    }

    @Test
    public void listarTodosLosOdontologos(){
        List<Odontologo> odontologoTest = odontologoService.listarOdontologos();
        assertFalse(odontologoTest.isEmpty());


    }

}

